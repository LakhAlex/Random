import * as THREE from '../build/three.module.js';
/* three.js 라이브러리를 module 버전으로 import하고 있습니다. 
   three.module.js 파일은 build 폴더에 존재
*/

class App{
    constructor() {
        /*  
            id가 webgl-container인 div 요소를 얻어 와서 divContainer라는
            이름으로 저장. 
        */
        const divContainer = document.querySelector("#webgl-container");

        /*  그리고 divContainer를 클래스의 field로 정의하고 있다..  
            이렇게 field로 정의한 이유는 이 divContainer를 this._divContainer로
            다른 method에서 참조할 수 있도록 하기 위해서이다.
        */
        this._divContainer = divContainer;

        /*
            renderer 객체는 three.js의 webGLRenderer라는 클래스로 생성할 수 있다.
            생성할 때 다양한 옵션을 설정할 수 있는데 여기서는 antialias를 true로
            설정하고 있다.
            이 처럼 renderer 객체에 antialias를 활성화 시켜주면 3차원 장면이 
            렌더링될 때 오브젝트들의 경계선이 계단 현상 없이 부드럽게 표현된다.
        */
        const renderer = new THREE.WebGLRenderer({antialias: true});

        /*  
            그리고 renderer 객체에 setPixelRatio method를 호출해서 픽셀의 
            ratio 값을 설정하고 있다.
            pixel ratio 값은 window의 devicePixelRatio 속성으로 쉽게
            얻을 수 있다.
        */
        renderer.setPixelRatio(window.devicePixelRatio);

        /*
            이렇게 생성된 renderer의 domElement를 id가 webgl-container인
            divContainer의 자식으로 추가한다.
            renderer.domElement는 canvas 타입의 dom 객체이다.
        */
        divContainer.appendChild(renderer.domElement);

        /*
            그리고 renderer가 다른 method에서 참조할 수 있도록 
            this._renderer로 정의하고 있다.
        */
        this._renderer = renderer



        /* 
            Scene 객체를 생성하는 코드
            Scene 객체는 three.js 라이브러리에서 Scene 클래스로 간단히
            생성할 수 있다.
        */
        const scene = new THREE.Scene();

        /*
            scene 객체를 fielf화 시키고 있다.
            App 클래스의 다른 method에서도 참조할 수 있도록 하였다.
        */
        this._scene = scene;



        /*
            camera 객체를 구성하는 _setupCamera method를
            호출하고 있다.
        */
        this._setupCamera();

        /*
            광원을 설정하는 _setupLight method를 호출하고 있다.
        */
        this._setupLight();

        /*
            3차월 모델을 설정하는 _setupModel method를 호출하고 있다.
        */
        this._setupModel();


        /*
            밑즐로 시작하는 field와 method가 있다.
            밑줄로 시작하는 이유는 밑줄로 시작하는 field와 method는 이 App
            클래스 내부에서만 사용되는 private field, private method라는 의미
            하지만 javascript에서는 클래스를 정의할 때 private 성격을
            부여할 수 있는 기능이 없다.
            그래서 개발자들간의 약속으로 밑줄로 시작하면 private로 인식함.
            밑줄로 시작하면 App 클래스 외부에서는 밑줄로 시작하는 field와
            method를 호출해서는 안된다.
        */



        /*
            창 크기가 변경되면 발생하는 ' onresize ' 이벤트에 이 클래스의
            resize method를 지정하고 있습니다.
            resize 이벤트가 필요한 이유는 renderer나 camera는 창 크기가
            변경될 때 마다 그 크기에 맞게 속성 값을 재설정해줘야 하기 때문.

            resize 이벤트에 rezie method를 지정할 때 bind를 사용해서 지정하고 있다.
            이유: rezie method 안에서 this가 가르키는 객체가 이벤트 객체가 아닌 이
                  App 클래스의 객체가 되도록 하기 위해서 입니다.
        */
        window.onresize = this.resize.bind(this);

        /*  rezie method를 창 크기가 변경될 때 발생하는 reszie 이벤트와는
            상관없이 생성자에서 한번 무조건 적으로 호출하고 있음.
            이렇게 함으로써 renderer나 camera의 창 크기에 맞게 설정해 주게 됨.  */
        this.resize();

        /*  render method를 requestAnimationFrame이라는 API에 넘겨줘서 호출하고 있다.
            render method는 실제로 3차원 그래픽 장면을 만들어주는 method임.

            이 method를 requestAnimationFrame에 넘겨줘서 requestAnimationFrame은
            적당한 시점에 또한 최대한 빠르게 이 render method를 호출해 준다.

            그런데 여기서 render method를 bind를 통해서 넘겨주고 있다.
            이유: render method의 코드 안에서 사용되는 this가 바로
                  이 App 클래스의 객체럴 가르키도록 하기 위함이다.  */
        requestAnimationFrame(this.render.bind(this));
    }



    _setupCamera(){
        /* 3차원 그래픽을 출력할 영역에 대한 크기를 가져옴 */
		const width = this._divContainer.clientWidth;
		const height = this._divContainer.clientHeight;
		/* 크기를 이용해서 카메라 객체 생성 */
		const camera = new THREE.PerspectiveCamera( 
            75, width / height, 0.1, 100
        );
		camera.position.z = 2;

        /*  생성되는 카메라 객체를 또 다른 method에서 
            사용할 수 있도록 this._camera라는 field로 정의 */
		this._camera = camera;
    }

    _setupLight() {
		/* 광원의 색상과 광원의 세기 값을 설정 */
		const color = 0xffffff;
		const intensity = 1;
		/* 광원 객체 생성 */
		const light = new THREE.DirectionalLight(color, intensity);
        /* 광원의 위치를 설정 */
		light.position.set(-1, 2, 4);
        /* 생성한 광원을 scene 객체의 구성요소로 추가 */
		this._scene.add(light);
	}

	/* 파란색 정육면체 mesh를 생성하는 method */
	_setupModel() {
		/* 형태 : BoxGeometry(가로, 세로, 깊이) */
		const geometry = new THREE.BoxGeometry(1, 1, 1);
		/* 재질 */
		const material = new THREE.MeshPhongMaterial({color: 0x44a88});
		
		/* mesh 생성 */
		const cube = new THREE.Mesh(geometry, material);

		/* scene 객체의 구성요소로 추가 */
		this._scene.add(cube);
		this._cube = cube;
	}

    resize() {
		const width = this._divContainer.clientWidth;
		const height = this._divContainer.clientHeight;

		/* camera 속성 변경 */
		this._camera.aspect = width / height;
		this._camera.updateProjectionMatrix();

		/* renderer 의 크기 설정 */
		this._renderer.setSize(width, height);
	}

	/*  time : requestAnimationFrame 가 render 함수에 전달해주는 값 
        time 인자는 렌더링이 처음 시작된 이후 경과도니 시간값으로
        단위는 milli-second 입니다. 
        time 인자를 통해서 scene의 애니메이션에 이용할 수 있습니다. */
	render(time) {
		/* renderer 가 scene 을 카메라 시점으로 렌더링하도록 함 */
		this._renderer.render(this._scene, this._camera);
		/* time 인자 : 렌더링이 처음 시작된 이후 경과된 시간값. millisecond unit */
		this.update(time);
		/* 생성자 코드와 동일 */
		requestAnimationFrame(this.render.bind(this));
	}

	update(time) {
		time *= 0.001; // second unit
		/* 정육면체의 회전 값에 time 값을 지정 */
		this._cube.rotation.x = time;
		this._cube.rotation.y = time;
	}
}
/* App이라는 이름의 클래스 생성 
   앞으로 추가될 코드는 이 App 클래스의 구현 코드
*/

window.onload = function() {
    new App();
}
/* 그리고 window의 onload에서 이 App 클래스의 객체를 생성하고 있습니다. */



/* ---------------------------------------------------------------- */

/*
    [ three.js의 기본 구성요소 ]

    three.js는 3차원 객체로 구성되는 장면(Scene)이 있다.
    이 장면을 모니터와 같은 출력장치에 출력할 수 있는 렌더링을 하는 
    Renderer가 있다.
    장면을 렌더링할때는 어떤 시점에서 장면을 보는가에 
    따라서 다양한 모습으로 렌더링되는데요.
    그 시점을 카메라로 정의합니다.

    다시 장면(Scene)는 Light와 3차원 모델인 Mesh로 구성됩니다.
    3차원 형상이 화면상에 표시되기 위해서는 적절한 광원이 필요하기 때문에
    이 light가 필요한 것입니다.
    그리고 이 mesh는 Object3D의 파생 클래스인데 Mesh는 형상 등을 정의하는
    Gemoetry와 색상 및 투명도 등을 정의하는 Material로 정의 됩니다.

*/